from django.shortcuts import render
from app1.models import Customer
from app1.forms import CustomerForm
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa

def add_customer(request):
    form = CustomerForm()
    template_name = "app1/add_customer.html"
    context = {'form':form}
    if request.method == "POST":
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
    return render(request, template_name, context)


    
def show_customer(request):
    form = Customer.objects.all()
    context = {"form":form}
    template_name = "app1/showinfo.html"
    return render(request, template_name, context)

def pdf_convert(request):
    form = Customer.objects.all()
    template_path = "app1/pdf_convert.html"
    context = {'form': form}
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = ' attachment; filename="Customer.pdf"'
    
    template = get_template(template_path)
    html = template.render(context)
    pisa_status = pisa.CreatePDF(
       html, dest=response)

    if pisa_status.err:
       return HttpResponse('We had some errors <pre>' + html + '</pre>')
    return response
