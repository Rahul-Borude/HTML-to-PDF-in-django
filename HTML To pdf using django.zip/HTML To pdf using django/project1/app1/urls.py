from django.urls import path
from app1.views import add_customer,show_customer, pdf_convert

urlpatterns = [
    path('ac/',add_customer,name='customerurl'),
    path('sc/',show_customer,name='showcustomerurl'),
    path('pv/', pdf_convert, name='pdfurl')
]
